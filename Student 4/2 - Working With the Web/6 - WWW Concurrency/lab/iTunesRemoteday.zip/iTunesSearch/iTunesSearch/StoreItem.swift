//
//  StoreItem.swift
//  iTunesSearch
//
//  Created by Luis Madriz on 11/17/21.
//

import Foundation

struct StoreItem: Codable {
    let name: String
    let artist: String
    var kind: String
    var description: String
    var artworkURL: URL
}

struct SearchResponse: Codable {
    let results: [StoreItem]
}
