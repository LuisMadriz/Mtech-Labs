//
//  LandMarksApp.swift
//  LandMarks
//
//  Created by Luis Madriz on 12/7/21.
//

import SwiftUI

@main
struct LandMarksApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
