//
//  ContentView.swift
//  ArchitectDirectoryApp
//
//  Created by Jonas Jacobs on 3/9/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, world!")
            .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
