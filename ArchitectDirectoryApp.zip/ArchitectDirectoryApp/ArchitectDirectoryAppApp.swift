//
//  ArchitectDirectoryAppApp.swift
//  ArchitectDirectoryApp
//
//  Created by Jonas Jacobs on 3/9/22.
//

import SwiftUI

@main
struct ArchitectDirectoryAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
