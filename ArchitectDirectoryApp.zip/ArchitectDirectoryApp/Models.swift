//
//  Models.swift
//  ArchitectDirectoryApp
//
//  Created by Jonas Jacobs on 3/9/22.
//

import Foundation
import SwiftUI

protocol ModelControllerProtocol {
    var p: [Person] { get }
    func removePerson (person: Person)
}

class ModelController: ModelControllerProtocol {
    var p: [Person]
    
    func removePerson(person: Person) {
        p.remove(at: 0)
    }
    
    init(p: [Person]) {
        self.p = p
    }
}

struct Person {
    var name: String
    var email: String
}

class MyViewController: UIViewController, UITableViewDataSource {
    var model: ModelControllerProtocol
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return UITableViewCell()
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        model.person.count
    }
    
    init(model: ModelControllerProtocol) {
        self.model = model
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
//
//class FakeModelController: ModelControllerProtocol {
//    var person: [Person] = [Person(name: "Fake", email: "Fake")]
//
//    func removePerson(person: String) {
//        // haha. do nothing
//    }
//}
//
//
//let fake = FakeModelController()
//let vc = MyViewController(fake)
//
//

