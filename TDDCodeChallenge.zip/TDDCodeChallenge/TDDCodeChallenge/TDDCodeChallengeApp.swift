//
//  TDDCodeChallengeApp.swift
//  TDDCodeChallenge
//
//  Created by Luis Mosqueda on 3/8/22.
//

import SwiftUI

@main
struct TDDCodeChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
