//
//  ContentView.swift
//  TDDCodeChallenge
//
//  Created by Luis Mosqueda on 3/8/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, world!")
            .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
