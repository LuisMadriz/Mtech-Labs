//
//  EvenNumber.swift
//  TDDCodeChallengeTests
//
//  Created by Luis Mosqueda on 3/8/22.
//

import Foundation

struct EvenNumber {
   static func evenNumbers(numbers: [Int]) -> [Int] {
       var evenNumbers: [Int] = []
        for n in numbers {
            if(n % 2 == 0) {
                evenNumbers.append(n)
               print("\(n) is even")
            } else {
                print("\(n) is odd")
            }
        }
        return evenNumbers
    }
}

